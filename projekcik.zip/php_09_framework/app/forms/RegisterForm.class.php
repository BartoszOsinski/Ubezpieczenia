<?php

namespace app\forms;

class RegisterForm {
    public $idosoby;
    public $imie;
    public $nazwisko;
    public $pesel;
    public $login;
    public $haslo;
    public $powtorzhaslo;
}