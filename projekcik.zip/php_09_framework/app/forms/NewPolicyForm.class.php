<?php

namespace app\forms;

class NewPolicyForm {
    public $Id_polisy;
    public $Id_Klienta;
    public $Id_Agenta;
    public $Id_Samochodu;
    public $Szkody;
    public $Prawo_jazdy;
    public $Data_Pocz;
    public $Data_Konca;
    public $OC;
    public $AC;
    public $NNW;
    public $Assistance;
    public $Wartosc;
    public $Cena;
}