<?php

namespace app\forms;

class NewCarForm {
    public $Id_Samochodu;
    public $Numer_Rejestracyjny;
    public $VIN;
    public $Data_Pierwszej_Rejestracji;
    public $Marka;
    public $Model;
    public $Rok_Produkcji;
    public $przebieg;

}