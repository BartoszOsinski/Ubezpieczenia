<?php


namespace app\controllers;



class NewPolicyAgentCtrl
{
    private $form;
    public function __construct()
    {
        $this->form = new NewPolicyForm;
        $this->form = new NewCarForm;

    }
}