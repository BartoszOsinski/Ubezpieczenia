<?php


namespace app\controllers;

use app\forms\LoginForm;
use core\SessionUtils;
use core\App;
use core\ParamUtils;
use core\RoleUtils;
use core\Utils;

class LoginCtrl
{

    private $form;

    public function __construct()
    {
        $this->form = new LoginForm();
    }

    public function validate()
    {
        $this->form->login = ParamUtils::getFromRequest('login');
        $this->form->haslo = ParamUtils::getFromRequest('haslo');

        if (!isset($this->form->login)) {
            return false;
        }

        if (empty($this->form->login)) {
            Utils::addErrorMessage('Nie podano loginu');
        }
        if (empty($this->form->haslo)) {
            Utils::addErrorMessage('Nie podano hasła');
        }

        if (App::getMessages()->isError()) {
            return false;
        }
        $this->form->passworddb = App::getDB()->select("user", ["haslo"], ["login" => $this->form->login]);

        if ($this->form->passworddb[array_key_first(
                $this->form->passworddb
            )]['haslo'] == $this->form->haslo) {
            RoleUtils::addRoleFromDatabase($this->form->login);

        } else {
            Utils::addErrorMessage('Niepoprawny login lub hasło');
        }

        SessionUtils::store('currentUser',$this->form->login );
        return !App::getMessages()->isError();
    }
    public function action_LoginRegister()
    {
        Utils::addInfoMessage('Zaloguj się aby zakończyć rejestracje');
        $this->generateView();
    }

    public function action_Login()
    {
        if ($this->validate()) {
            RoleUtils::removeRole('GUEST');
            App::getRouter()->redirectTo("MainAfterLogin");
        } else {
            $this->generateView();
        }
    }
    public function action_Logout()
    {
        SessionUtils::remove('currentUser');
        session_destroy();

        App::getRouter()->redirectTo('Main');
    }
    public function generateView()
    {
        App::getSmarty()->display('login.tpl');
    }

}