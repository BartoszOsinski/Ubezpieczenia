<?php


namespace app\controllers;

use app\forms\LoginForm;
use app\forms\RegisterForm;
use core\App;
use core\ParamUtils;
use core\RoleUtils;
use core\Utils;
use PDOException;


class RegisterCtrl
{

    private $form;

    public function __construct()
    {
        $this->form = new RegisterForm();
    }
    public function validate()
    {
        $this->form->imie = ParamUtils::getFromRequest('imie');
        $this->form->nazwisko = ParamUtils::getFromRequest('nazwisko');
        $this->form->pesel = ParamUtils::getFromRequest('pesel');
        $this->form->login = ParamUtils::getFromRequest('login');
        $this->form->haslo = ParamUtils::getFromRequest('haslo');
        $this->form->powtorzhaslo = ParamUtils::getFromRequest('powtorzhaslo');

        if (!isset($this->form->login)) {
            return false;
        }
        if (empty($this->form->imie)) {
            Utils::addErrorMessage('Brak Imienia');
        }
        if (empty($this->form->nazwisko)) {
            Utils::addErrorMessage('Brak Nazwiska');
        }
        if (empty($this->form->pesel)) {
            Utils::addErrorMessage('Brak PESELU');
        }
        if (empty($this->form->login)) {
            Utils::addErrorMessage('Brak Loginu');
        }
        if (empty($this->form->haslo)) {
            Utils::addErrorMessage('Brak Hasla');
        }
        if (empty($this->form->powtorzhaslo)) {
            Utils::addErrorMessage('Brak Powtórzonego Hasła');
        }

        if (strlen($this->form->pesel) > 11) {
            Utils::addErrorMessage('Zły PESEL');
        }

        if(strcmp($this->form->haslo,$this->form->powtorzhaslo)){
            Utils::addErrorMessage('Podane hasłą są inne');
        }
        if (App::getMessages()->isError()) {
            return false;
        }
        try{ App::getDB()->insert(
            'user',
            [
                'Imię' => $this->form->imie,
                'Nazwisko' => $this->form->nazwisko,
                'Pesel' => $this->form->pesel,
                'Login' => $this->form->login,
                'Hasło' => $this->form->haslo,
            ]
        );
        }catch(PDOException $e){
            if($e->errorInfo[1] == 1062)
                Utils::addErrorMessage('Podany login juz istnieje');
        }
        return !App::getMessages()->isError();
    }

    public function action_Register()
    {
        if ($this->validate()) {
            App::getRouter()->redirectTo("LoginRegister");
        } else {
            $this->generateView();
        }
    }
    public function generateView()
    {
        App::getSmarty()->display('new_account.tpl');
    }

}

    ?>