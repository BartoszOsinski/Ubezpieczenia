<?php


namespace app\controllers;

use app\forms\LoginForm;
use app\forms\RegisterForm;
use Cassandra\RetryPolicy\Fallthrough;
use core\App;
use core\ParamUtils;
use core\RoleUtils;
use core\Utils;
use PDOException;


class NewPolicyClientCtrl
{
    private $form;
    public function __construct()
    {
        $this->form = new NewPolicyForm;
        $this->form = new NewCarForm;

    }
}