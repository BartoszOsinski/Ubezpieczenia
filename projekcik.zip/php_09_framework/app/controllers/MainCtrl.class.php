<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\SessionUtils;
use core\Utils;

/**
 * HelloWorld built in Amelia - sample controller
 *
 * @author Przemysław Kudłacik
 */
class MainCtrl {
    
    public function action_Main() {

        App::getSmarty()->display('main.tpl');
    }
    public function action_MainAfterLogin() {

        App::getSmarty()->display('main_afterlogin.tpl');
    }

    public function action_gotoLogin() {

        session_destroy();
        App::getSmarty()->display('login.tpl');
    }

    public function action_Client() {

        App::getSmarty()->display('client_profile.tpl');
    }
    public function action_Agent() {

        App::getSmarty()->display('agent_profile.tpl');
    }
    public function action_Admin() {
        App::getSmarty()->display('admin_profile.tpl');
    }
    public function action_NewPolicy() {
        App::getSmarty()->display('new_policy.tpl');
    }

    public function action_logout()
    {
        SessionUtils::remove('currentUser');
        session_destroy();

        App::getRouter()->redirectTo('Main');
    }




    
}
