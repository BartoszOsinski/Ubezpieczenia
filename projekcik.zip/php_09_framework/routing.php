<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('Main'); #default action
App::getRouter()->setLoginRoute('gotologin'); #action to forward if no permissions

Utils::addRoute('Main', 'MainCtrl');
Utils::addRoute('MainAfterLogin', 'MainCtrl');
Utils::addRoute('gotoLogin', 'MainCtrl');
Utils::addRoute('Client', 'MainCtrl');
Utils::addRoute('Agent', 'MainCtrl');
Utils::addRoute('Admin', 'MainCtrl');
Utils::addRoute('Login', 'LoginCtrl');
Utils::addRoute('Logout', 'MainCtrl');
Utils::addRoute('LoginRegister', 'LoginCtrl');
Utils::addRoute('Register', 'RegisterCtrl');
Utils::addRoute('NewPolicy', 'MainCtrl');








//Utils::addRoute('action_name', 'controller_class_name');