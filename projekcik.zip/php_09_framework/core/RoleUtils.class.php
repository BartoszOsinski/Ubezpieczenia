<?php

namespace core;

/**
 * Wrapper class for role utility functions
 *
 * @author Przemysław Kudłacik
 */
class RoleUtils {

    public static function addRoleFromDatabase($forWho)
    {
        $rolesformdatabase = App::getDB()->select(
            "katalog_user_role",
            [
                // Here is the table relativity argument that tells the relativity between the table you want to join.
                "[>]role" => ["idroli" => "idroli"],
                "[>]user" => ["idosoby" => "idosoby"]
            ],
            [
                "role.nazwaroli"

            ],
            [
                "osoby.login" => $forWho
            ]
        );


        foreach ($rolesformdatabase as $value) {
            if ($value['Nazwa_Roli'] == "CLIENT") {
                RoleUtils::addRole('CLIENT');
            }
            if ($value['Nazwa_Roli'] == "AGENT") {
                RoleUtils::addRole('AGENT');
            }
            if ($value['Nazwa_Roli'] == "ADMIN") {
                RoleUtils::addRole('ADMIN');
            }
        }
    }

    public static function addRole($role) {
        App::getConf()->roles [$role] = true;
        $_SESSION['_amelia_roles'] = serialize(App::getConf()->roles);
    }

    public static function removeRole($role) {
        if (isset(App::getConf()->roles [$role])) {
            unset(App::getConf()->roles [$role]);
            $_SESSION['_amelia_roles'] = serialize(App::getConf()->roles);
        }
    }

    public static function inRole($role) {
        return isset(App::getConf()->roles[$role]);
    }

    public static function requireRole($role, $fail_action = null) {
        if (!self::inRole($role)) {
            if (isset($fail_action))
                App::getRouter()->forwardTo($fail_action);
            else
                App::getRouter()->forwardTo(App::getRouter()->getLoginRoute());
        }
    }

}
