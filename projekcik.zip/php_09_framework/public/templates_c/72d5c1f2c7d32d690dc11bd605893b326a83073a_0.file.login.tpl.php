<?php
/* Smarty version 3.1.33, created on 2022-05-30 20:07:42
  from 'C:\xampp\htdocs\php_09_framework\app\views\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_629507ee6e02e3_77296876',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '72d5c1f2c7d32d690dc11bd605893b326a83073a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_09_framework\\app\\views\\login.tpl',
      1 => 1653933852,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
  ),
),false)) {
function content_629507ee6e02e3_77296876 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>


<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Ubezpieczenia Samochodowe </title>
    <link href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,100,700,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/animate.css">
</head>
<body>
<header id="header">
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid top-nav">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Main">Strona Główna</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Client">Panel Klienta</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Agent">Panel Agenta</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Admin">Panel Admina</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Login">Zaloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
    <!-- Slider -->

    <!-- Contact Section -->
    <section id="contact">
        <div class="container-fluid wrapper">
            <div class="row">
                <div>
                    <h2 class="section-heading">Logowanie</h2>
                </div>
                <br>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Login" method="post">
                        <div class="row">
                            <div class="col-md-4 contact-form-box">

                                <div class="form-group">
                                    <h4>Login</h4> <input type="text" class="form-control" placeholder="Login" name="login">
                                </div>
                                <div class="form-group">
                                    <h4>Hasło</h4> <input type="password" class="form-control" placeholder="Hasło" name="haslo">
                                </div>
                                <div id="success"></div>
                                <button type="submit" class="btn btn-xl">Zaloguj</button>
                                <h3>Nie masz konta? Kliknij <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Register">tutaj</a> aby się zarejestrować</h3>

                    </form>
                    <?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer -->
    <footer>
        <div class="container-fluid wrapper">
            <div class="col-lg-12 footer-info">
                <a class="footer-logo" href="#header">
                    <img class="img-responsive" src="img/footer-logo.png" alt="logo-footer">
                </a>
                <p class="footer-text">Strona wykonana przez Bartosz Osiński </p>
            </div>
            <div class="col-sm-6 col-md-12 social-icons-footer">
                <ul class="list-inline social-buttons">
                    <li><a href="#"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li><a href="#"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li><a href="#"><i class="fa fa-google"></i></a>
                    </li>
                </ul>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-12 copyright-bottom">
                <span class="copyright">Copyright &copy; xBe 2016 Created By <a href="http://templatestock" target="_blank">Template Stock</a> </span>
            </div>
        </div>
    </footer>
    <!-- Scroll-up -->
    <div class="scroll-up">
        <a href="#header" class="page-scroll"><i class="fa fa-angle-up"></i></a>
    </div>
    <div id="theme-settings">
        <div id="settings-button">
        </div>
        <div class="color">
            <span class="settings-title">Theme color selector</span>
            <ul class="gradients">
                <li>
                    <div class="gradient1">
                    </div>
                </li>
                <li>
                    <div class="gradient2">
                    </div>
                </li>
                <li>
                    <div class="gradient3">
                    </div>
                </li>
                <li>
                    <div class="gradient4">
                    </div>
                </li>
                <li>
                    <div class="gradient5">
                    </div>
                </li>
                <li>
                    <div class="gradient6">
                    </div>
                </li>
                <li>
                    <div class="gradient7">
                    </div>
                </li>
                <li>
                    <div class="gradient8">
                    </div>
                </li>
            </ul>
        </div>
    </div>

    <!-- jQuery -->
    <?php echo '<script'; ?>
 src="js/jquery.js"><?php echo '</script'; ?>
>
    <!-- Bootstrap Core JavaScript -->
    <?php echo '<script'; ?>
 src="js/bootstrap.min.js"><?php echo '</script'; ?>
>
    <!-- Color Settings script -->
    <?php echo '<script'; ?>
 src="js/settings-script.js"><?php echo '</script'; ?>
>
    <!-- Plugin JavaScript -->
    <?php echo '<script'; ?>
 src="js/jquery.easing.min.js"><?php echo '</script'; ?>
>
    <!-- Contact Form JavaScript -->
    <?php echo '<script'; ?>
 src="js/jqBootstrapValidation.js"><?php echo '</script'; ?>
>
    
    <!-- SmoothScroll script -->
    <?php echo '<script'; ?>
 src="js/smoothscroll.js"><?php echo '</script'; ?>
>
    <!-- Custom Theme JavaScript -->
    <?php echo '<script'; ?>
 src="js/xBe.js"><?php echo '</script'; ?>
>
    <!-- Isotope -->
    <?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.isotope.min.js"><?php echo '</script'; ?>
>
    <!-- Google Map -->
    <?php echo '<script'; ?>
 src="http://maps.googleapis.com/maps/api/js?extension=.js&output=embed"><?php echo '</script'; ?>
>
    <!-- Footer Reveal scirt -->
    <?php echo '<script'; ?>
 src="js/footer-reveal.js"><?php echo '</script'; ?>
>

</body>

</html><?php }
}
