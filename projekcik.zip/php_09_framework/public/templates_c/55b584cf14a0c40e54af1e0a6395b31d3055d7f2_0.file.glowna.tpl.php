<?php
/* Smarty version 3.1.33, created on 2022-05-29 18:05:49
  from 'C:\xampp\htdocs\php_09_framework\app\views\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_629399ddbdd6a1_01313924',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '55b584cf14a0c40e54af1e0a6395b31d3055d7f2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_09_framework\\app\\views\\main.tpl',
      1 => 1653840340,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629399ddbdd6a1_01313924 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>


<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Ubezpieczenia Samochodowe </title>
    <link href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/style.css">
   <link href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/font-awesome.min.css" rel="stylesheet" type="text/css">
   <link href='https://fonts.googleapis.com/css?family=Lato:400,300,100,700,900' rel='stylesheet' type='text/css'>
   <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
   <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/animate.css">
</head>
<body>
<header id="header">
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid top-nav">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden nav-buttons">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#portfolio">Strona Główna</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#pricing">Panel Klienta</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#clients">Panel Agenta</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#testimonials">Panel Admina</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#contact">Wyloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
    <section id="slider">
      <div id="myCarousel-one" class="carousel slide">
       <ol class="carousel-indicators">
            <li data-target="#myCarousel-one" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel-one" data-slide-to="1"></li>
        </ol>
            <div class="carousel-inner">
                <div class="item active">
                    <div class="carousel-caption wrapper">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="intro-text">
                                    <h1 class="intro-lead-in animated bounceInLeft">Bartosz Osiński</h1>
                                    <h2 class="intro-heading animated bounceInRight">Ubezpieczenia</h2>
                                    <p class="intro-paragraph animated bounceInRight">Złóż wniosek o ubezpieczenie</p>
                                </div>
                                <a href="#services" class="page-scroll btn btn-xl slider-button animated bounceInUp">ZŁÓŻ WNIOSEK</a>
                            </div>
                        </div>
                    </div>
                    <img src="img/backgrounds/header-two.jpg" alt="slider-image"/>
                </div>
                <div class="item">
                    <div class="carousel-caption wrapper">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="intro-text">
                                    <h1 class="intro-lead-in animated bounceInLeft">Bartosz Osiński</h1>
                                    <h2 class="intro-heading animated bounceInRight">Ubezpieczenia</h2>
                                    <p class="intro-paragraph animated bounceInRight">Złóż wniosek o ubezpieczenie</p>
                                </div>
                                <a href="#services" class="page-scroll btn btn-xl slider-button animated bounceInUp">ZŁÓŻ WNIOSEK</a>
                            </div>
                        </div>
                    </div>
                    <img src="img/backgrounds/head.jpg" alt="slider-image"/>
                </div>
                    <a class="myCarousel-one-left" href="#myCarousel-one" data-slide="prev">
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <a class="myCarousel-one-right" href="#myCarousel-one" data-slide="next">
                        <i class="fa fa-angle-right"></i>
                    </a>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services">
        <div class="container-fluid wrapper">
            <div class="row">
                <div class="col-lg-12 text-left">
                    <h2 class="section-heading">Nasza Oferta</h2>
                    <h3 class="section-subheading">Oferujemy wiele rodzaji ubezpieczeń samochodowych </h3>
                </div>
            </div>
            <div class="row text-center">
                <!-- First row services -->
                <div class="row first-services">
                    <div class="col-sm-12 col-md-4 service">
                        <h4 class="service-heading">OC</h4>
                        <p class="text-services">Odpowiedzialność cywilna (OC) jest obowiązkowym ubezpieczeniem dającym ochrone ubezpieczeniową, gdy ubezpieczony będzie zobowiązany do naprawienia wyrządzonej szkody</p>
                    </div>
                    <div class="col-sm-12 col-md-4 service">
                        <h4 class="service-heading">AC</h4>
                        <p class="text-services">Autocasco (AC) należy do dobrowolnych ubezpieczeń komunikacyjnych, które chronią samochód oraz jego wyposażenie standardowe i dodatkowe przed uszkodzeniem, zniszczeniem czy kradzieżą.</p>
                    </div>
                    <div class="col-sm-12 col-md-4 service">
                        <h4 class="service-heading">NNW</h4>
                        <p class="text-services">Następstwa Nieszczęśliwych Wypadków - ubezpieczenie od następstw nieszczęśliwych wypadków. Rodzaj dodatkowego ubezpieczenia osobowego. Ochroną objęte jest życie i zdrowie ubezpieczonego.</p>
                    </div>
                </div>
                <!-- Second row services -->
                <div class="row second-services">
                    <div class="col-sm-12 col-md-4 service">
                        <h4 class="service-heading">ASSISTANCE</h4>
                        <p class="text-services">Assistance zapewnia Ci pomoc towarzystwa ubezpieczeniowego, gdy Twój samochód nagle stanie i dalsza jazda nim jest niemożliwa.</p>
                    </div>
                    <div class="col-sm-12 col-md-4 service">
                        <h4 class="service-heading">NAJLEPSZE CENY</h4>
                        <p class="text-services">Jedne z najlepszych cen ubezpieczeń samochodwych na rynku</p>
                    </div>
                    <div class="col-sm-12 col-md-4 service">
                        <h4 class="service-heading">SZYBKIE UBEZPIECZENIE</h4>
                        <p class="text-services">Szybkie ubezpieczanie</p>
                    </div>
                </div>
            </div>
	</div>
    </section>

    <!-- jQuery -->
    <?php echo '<script'; ?>
 src="js/jquery.js"><?php echo '</script'; ?>
>
    <!-- Bootstrap Core JavaScript -->
    <?php echo '<script'; ?>
 src="js/bootstrap.min.js"><?php echo '</script'; ?>
>
    <!-- Color Settings script -->
    <?php echo '<script'; ?>
 src="js/settings-script.js"><?php echo '</script'; ?>
>
    <!-- Plugin JavaScript -->
    <?php echo '<script'; ?>
 src="js/jquery.easing.min.js"><?php echo '</script'; ?>
>
    <!-- Contact Form JavaScript -->
    <?php echo '<script'; ?>
 src="js/jqBootstrapValidation.js"><?php echo '</script'; ?>
>
    
    <!-- SmoothScroll script -->
    <?php echo '<script'; ?>
 src="js/smoothscroll.js"><?php echo '</script'; ?>
>
    <!-- Custom Theme JavaScript -->
    <?php echo '<script'; ?>
 src="js/xBe.js"><?php echo '</script'; ?>
>
    <!-- Isotope -->
    <?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.isotope.min.js"><?php echo '</script'; ?>
>
    <!-- Google Map -->

    <!-- Footer Reveal scirt -->
    <?php echo '<script'; ?>
 src="js/footer-reveal.js"><?php echo '</script'; ?>
>

</body>

</html><?php }
}
