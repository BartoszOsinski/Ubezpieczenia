<?php
/* Smarty version 3.1.33, created on 2022-06-03 20:17:29
  from 'C:\xampp\htdocs\php_09_framework\app\views\templates\mainnologinfooter.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_629a5039928d92_20320475',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fef99d4fec88449d7d566beb8f99faedaef20c8d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_09_framework\\app\\views\\templates\\mainnologinfooter.tpl',
      1 => 1654280242,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629a5039928d92_20320475 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>


<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Ubezpieczenia Samochodowe </title>
    <link href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,100,700,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/animate.css">
</head>
<body>
<header id="header">
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid top-nav">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Main">Strona Główna</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Client">Panel Klienta</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Agent">Panel Agenta</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Admin">Panel Admina</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
gotoLogin">Zaloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_393119938629a5039928843_84046354', 'Main');
?>


<!-- Scroll-up -->
<div class="scroll-up">
    <a href="#header" class="page-scroll"><i class="fa fa-angle-up"></i></a>
</div>
<div id="theme-settings">
    <div id="settings-button">
    </div>
    <div class="color">
        <span class="settings-title">Theme color selector</span>
        <ul class="gradients">
            <li>
                <div class="gradient1">
                </div>
            </li>
            <li>
                <div class="gradient2">
                </div>
            </li>
            <li>
                <div class="gradient3">
                </div>
            </li>
            <li>
                <div class="gradient4">
                </div>
            </li>
            <li>
                <div class="gradient5">
                </div>
            </li>
            <li>
                <div class="gradient6">
                </div>
            </li>
            <li>
                <div class="gradient7">
                </div>
            </li>
            <li>
                <div class="gradient8">
                </div>
            </li>
        </ul>
    </div>
</div>

<!-- jQuery -->
<?php echo '<script'; ?>
 src="js/jquery.js"><?php echo '</script'; ?>
>
<!-- Bootstrap Core JavaScript -->
<?php echo '<script'; ?>
 src="js/bootstrap.min.js"><?php echo '</script'; ?>
>
<!-- Color Settings script -->
<?php echo '<script'; ?>
 src="js/settings-script.js"><?php echo '</script'; ?>
>
<!-- Plugin JavaScript -->
<?php echo '<script'; ?>
 src="js/jquery.easing.min.js"><?php echo '</script'; ?>
>
<!-- Contact Form JavaScript -->
<?php echo '<script'; ?>
 src="js/jqBootstrapValidation.js"><?php echo '</script'; ?>
>

<!-- SmoothScroll script -->
<?php echo '<script'; ?>
 src="js/smoothscroll.js"><?php echo '</script'; ?>
>
<!-- Custom Theme JavaScript -->
<?php echo '<script'; ?>
 src="js/xBe.js"><?php echo '</script'; ?>
>
<!-- Isotope -->
<?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.isotope.min.js"><?php echo '</script'; ?>
>
<!-- Google Map -->
<?php echo '<script'; ?>
 src="http://maps.googleapis.com/maps/api/js?extension=.js&output=embed"><?php echo '</script'; ?>
>
<!-- Footer Reveal scirt -->
<?php echo '<script'; ?>
 src="js/footer-reveal.js"><?php echo '</script'; ?>
>

</body>

</html><?php }
/* {block 'Main'} */
class Block_393119938629a5039928843_84046354 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'Main' => 
  array (
    0 => 'Block_393119938629a5039928843_84046354',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
<?php
}
}
/* {/block 'Main'} */
}
