<?php
/* Smarty version 3.1.33, created on 2022-06-03 20:15:25
  from 'C:\xampp\htdocs\php_09_framework\app\views\client_profile.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_629a4fbdb286f0_65590929',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '924a4a897a3104bc95315c6c51414a111ba55e6f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_09_framework\\app\\views\\client_profile.tpl',
      1 => 1654280109,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629a4fbdb286f0_65590929 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_341231873629a4fbdb28006_13588643', 'Main');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "mainlogin.tpl");
}
/* {block 'Main'} */
class Block_341231873629a4fbdb28006_13588643 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'Main' => 
  array (
    0 => 'Block_341231873629a4fbdb28006_13588643',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <section id="contact">
        <div class="container-fluid wrapper">
            <div class="row">
                <div>
                    <h2 class="section-heading">Profil Klienta</h2>
                </div>
                <br>
            </div>
            <h2>Moje Polisy</h2>
            <div class="table">
                                    <table>
                                    <thead>
                                    <tr>
                                        <th>Id_Polisy</th>
                                        <th>Numer Rejestracyjny</th>
                                        <th>Marka</th>
                                        <th>Model</th>
                                        <th>Data początku ubezpieczenia</th>
                                        <th>Data końca ubezpieczenia</th>
                                        <th>OC</th>
                                        <th>AC</th>
                                        <th>NNW</th>
                                        <th>Assistance</th>
                                        <th>Wartość Pojazdu</th>
                                        <th>Cena Ubezpieczenia</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td> 1 </td>
                                        <td>132452345234525523</td>
                                        <td>2e5rytetyt</td>
                                        <td>3tert</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>4</td>
                                        <td>5</td>
                                    </tr>
                                    </tbody>
                                    </table>
            </div>
            <br>
            <h2>Moje Samochody</h2>
            <div class="table">
                <table>
                    <thead>
                    <tr>
                        <th>Id Samochodu</th>
                        <th>Numer Rejestracyjny</th>
                        <th>VIN</th>
                        <th>Marka</th>
                        <th>Model</th>
                        <th>Rok</th>
                        <th>Produkcji</th>
                        <th>Przebieg</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>132</td>
                        <td>2e5</td>
                        <td>3te</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>5</td>
                        <td>5</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

<?php
}
}
/* {/block 'Main'} */
}
