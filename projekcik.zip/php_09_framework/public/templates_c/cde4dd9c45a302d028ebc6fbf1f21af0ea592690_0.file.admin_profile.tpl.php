<?php
/* Smarty version 3.1.33, created on 2022-06-03 20:55:12
  from 'C:\xampp\htdocs\php_09_framework\app\views\admin_profile.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_629a5910c8a482_78130016',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cde4dd9c45a302d028ebc6fbf1f21af0ea592690' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_09_framework\\app\\views\\admin_profile.tpl',
      1 => 1654282512,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629a5910c8a482_78130016 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1878845766629a5910c85533_11700606', 'Main');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "mainlogin.tpl");
}
/* {block 'Main'} */
class Block_1878845766629a5910c85533_11700606 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'Main' => 
  array (
    0 => 'Block_1878845766629a5910c85533_11700606',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<section id="contact">
    <div class="container-fluid wrapper">
        <div class="row">
            <div>
                <h2 class="section-heading">Panel Administracyjny</h2>
            </div>
            <br>
        </div>
        <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
Admin">
            <h2>Opcje wyszukiwania</h2>
            <fieldset>
                <input type="text" placeholder="nazwisko" name="Nazwisko" value="<?php echo $_smarty_tpl->tpl_vars['searchForm']->value->Nazwisko;?>
">
                <button type="submit">Filtruj</button>
            </fieldset>
        </form>

        <h2>Użytkownicy</h2>
        <div class="table">
            <table>
                <thead>
                <tr>
                    <th>Id_Osoby</th>
                    <th>Imię</th>
                    <th>Nazwisko</th>
                    <th>PESEL</th>
                    <th>Opcje</th>
                </tr>
                </thead>
                <tbody>

                    <tr><td><?php echo $_smarty_tpl->tpl_vars['p']->value["Id_Osoby"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["Imię"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["Nazwisko"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["PESEL"];?>
</td><td><button class="btn1" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
personEdit/<?php echo $_smarty_tpl->tpl_vars['p']->value['Id_Osoby'];?>
">Edytuj</button><button class="btn" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
personDelete/<?php echo $_smarty_tpl->tpl_vars['p']->value['Id_Osoby'];?>
">Usuń</button></td></tr>

                </tbody>
            </table>
        </div>
</section>
<?php
}
}
/* {/block 'Main'} */
}
